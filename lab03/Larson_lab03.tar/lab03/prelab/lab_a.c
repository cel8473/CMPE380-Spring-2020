/****************************************************************************
 Lab 3 student file
****************************************************************************/
#include <stdio.h>
int main(int argc, char *argv[]) {
   int age = 22;
   int height = 24 ;
   printf("I am %d years old.\n");
   printf("I am %d inches tall.\n", height);
   return 0; 
}
