/****************************************************************************
  Lab 3 student file
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
   char *p;
   p = (char *) malloc(7); /* Allocation #1 */
   strncpy(p, "word 1", 7);
   printf("%s\n", p);
   
   strncpy(p, "word 2", 7);
   printf("%s\n", p);
   
   strncpy(p, "word 3", 7);
   printf("%s\n", p);
   free(p);
   return 0;
}

